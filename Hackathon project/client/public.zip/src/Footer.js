import React from 'react';
import './App.css';

function Footer() {
  return (
    <div className="footer">
      Footer content
    </div>
  );
}

export default Footer;
