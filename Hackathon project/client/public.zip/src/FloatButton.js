import React from 'react';
import { FloatButton } from 'antd';
const Float = () => <FloatButton onClick={() => console.log('onClick')} />;
export default Float;